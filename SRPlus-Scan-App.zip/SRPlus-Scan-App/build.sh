#!/bin/ksh

# # Gelb für Überschriften und Informationen
# YEL="\033[49;1;33m"
# # Grün für Rückfragen und Positivmeldungen
# GRN="\033[49;0;32m"
# # Rot für Fehlermeldungen
# RED="\033[49;0;31m"
# # Blau für Kopfzeilen
# BLU="\033[49;1;34m"
# # Orange für Kopfzeilen
# ORG="\033[49;0;33m"
# # Reset
# RST="\033[0m"

# Make content of DB_SID and DB_USR lowercase by default
typeset -l DB_SID
typeset -l DB_USR

# IP of local web app server and RESTful service
LOCAL_SERVER_HOST="http:\/\/192.168.9.35\/mobile"

clear

###
### ACHTUNG
###
### Bitte vor der erstmaligen Ausführung des Scripts die lokale Arbeitskopie aus dem
### SVN auschecken:
###
### mkdir $HOME/SR+mobile
### mkdir $HOME/SR+mobile-build
### svn checkout --username=jnnnnnn https://svn.intern:8443/iapu/SRPlus/trunk/05_Entwicklung/01_Applikation/_WebserverMobile/SRPlus-Scan-App SR+mobile
### svn checkout --username=jnnnnnn https://svn.intern:8443/iapu/SRPlus/trunk/05_Entwicklung/01_Applikation/_Webserver/mobile SR+mobile-build
###
### Bitte anschließend den Inhalt von node-modules manuell in das Verzeichnis $HOME/SR+mobile/node-modules 
### kopieren, da sonst der Build nicht ausgeführt werden kann.
###

echo "${ORG}╔══════════════════════════════════════════════════════════════════════════════════╗"
echo "║ SR+ mobile Build Utility MacOS - Version 1.3 - Stand 26.06.2020                  ║"
echo "║                                                                                  ║"
echo "║ Das Utility erzeugt den lauffähigen Inhalt der SR+ mobile Cordova App.           ║"
echo "║ Während des Build-Prozesses werden folgende Dateien temporär geändert:           ║"
echo "║ - config.xml (Widget ID wird vergeben und Version wird aktualisiert)             ║"
echo "║ - src/index.htm (Base href wird zu /mobile/ geändert)                            ║"
echo "║ - src/environments/environment.ts (Aktuelles Datum/Zeit eintragen)               ║"
echo "║ - src/environments/environment.prod.ts (Aktuelles Datum/Zeit eintragen)          ║"
echo "║                                                                                  ║"
echo "║ Anschließend wird erst ionic build, dann cordova build aufgerufen                ║"
echo "║ um das Paket zu erstellen.                                                       ║"
echo "║                                                                                  ║"
echo "║ Zum Abschluss werden die o. g. geänderten Dateien wieder hergestellt             ║"
echo "║ (außer config.xml).                                                              ║"
echo "╚══════════════════════════════════════════════════════════════════════════════════╝"
echo ${RST}

##
## Korrekte Locale für SVN einstellen um Warnings zu vermeiden
##
export LC_CTYPE=de_DE.utf8


##
## Aktuellen Dienst prüfen
##
# if [[ $USERNAME != "uni97340" && $USERNAME != "uni97341" && $USERNAME != "uni97342" ]];then
# 	echo "${RED}Falscher Dienstbenutzer!"
# 	echo "Das Skript darf nur mit einem der Dienstbenutzer uni97340, uni97341 oder uni97342 ausgeführt werden."
# 	echo ${RST}
# 	exit 0
# fi


##
## Als nächstes Benutzernamen und Password für die SVN Autentifizierung erfragen
##
# unset SVNUSR
# unset SVNPWD

# echo "Bitte die Windows Anmeldedaten für das SVN-Repository eingeben."
# echo "Der Benutzername ist mit dem Wert in Klammern vorbelegt und kann per Enter bestätigt werden"
# echo ${GRN}
# echo -n "Benutzername [$SUDO_USER]: ${RST}"

# read SVNUSR

# # Wenn der Benutzer nur Enter gedrückt hat, wird der Benutzername aus SUDO_USER verwendet (Vorgabe)
# SVNUSR="${SVNUSR:-$SUDO_USER}"

# echo -n "${GRN}Passwort: ${RST}"
# stty -echo
# read -s SVNPWD
# stty echo
# echo
# echo "------------------------------------------------------------"

# # Wenn kein Passwort eingegeben wurde wird das Skript hier abgebrochen
# if [ "${SVNPWD:-unset}" == "unset" ];then
# 	echo 
# 	echo "${RED}Kein Passwort eingegeben. Prozess wird abgebrochen.${RST}"
# 	exit 0
# fi

if [[ "$1" -eq "-6" ]]; then
	answer=6
else
	echo
	echo "Verfügbare Zielumgebungen:"
	echo
	echo "${GRN}1 - native IOS-App für Entwicklung (v10e.sus.intern)"
	echo "2 - native IOS-App für Testumgebung (v10i.sus.intern)"
	echo "3 - native IOS-App für Preprod (v10a.sus.intern)"
	echo "4 - native IOS-App für Produktion (sus.intern)"
	echo
	echo "5 - Nur Ionic-App für eigene native App (deprecated)"
	echo
	echo "6 - Lokale Entwicklungsumgebung ($(echo ${LOCAL_SERVER_HOST} | sed -e 's/\\//g'))"
	echo
	echo "0 - Ende"
	echo

	echo -n "${ORG}Bitte Build Option wählen: ${RST}"
	read answer
fi

if [[ $answer -eq 0 ]]; then
	echo
	echo "Es wurden keine Änderungen vorgenommen."
	echo
	exit 0
fi

target="\/mobile"

if [[ $answer -eq 1 ]]; then
	environment="10e"
elif [[ $answer -eq 2 ]]; then
	environment="10i"
elif [[ $answer -eq 3 ]]; then
	environment="10a"
elif [[ $answer -eq 4 ]]; then
	environment=""
elif [[ $answer -eq 6 ]]; then 
	environment="000"
fi

if [[ $answer -eq 6 ]]; then 
	target="${LOCAL_SERVER_HOST}"
elif [[ $answer -ne 4 && $answer -ne 5 ]]; then
	target="https:\/\/v${environment}.sus.intern\/mobile"
fi

old_version=$(grep 'widget id' config.xml | sed -E 's/.*version="([0-9]*\.)([0-9]*\.)([0-9]*)[0-9]{3}".*/\1\2\3/')
echo 
echo "Die aktuelle Versionsnummer ist: ${old_version}"

if [[ "$1" -ne "-6" ]]; then
	echo -n "Neue Versionsnummer (${old_version}): "
	read version
fi

if [[ "${version}" = "" ]]; then
	version=$old_version
fi

echo 
echo -n "- config.xml aktualisieren... "
if [[ $answer -eq 4 ]]; then
	app_id="srpWeb"
	app_version=${version}
else 
	app_id="srpWebv${environment}"
	app_version="${version}$(echo ${environment} | sed -e 's/e/1/;s/i/2/;s/a/3/')"
fi
sed -i.sed -e 's/widget id="com.magicsoftware.srpWeb[^"]*"/widget id="com.magicsoftware.'"${app_id}"'"/' config.xml
sed -i.sed -e 's/\(widget.*\)version="[^"]*"/\1version="'${app_version}'"/' config.xml
sed -i.sed -e 's/\("CodePushServerUrl" \)value="[^"]*"/\1value="'${target}'"/' config.xml
echo "Done"

# echo
# echo -n "- SVN-Update wird ausgefuehrt... "

OLD_PWD=$(pwd)

# cd $HOME/SR+mobile-build
# svn update --username=${SVNUSR} --password=${SVNPWD} --trust-server-cert --non-interactive

cd $HOME/SR+mobile/SRPlus-Scan-App
# svn update --username=${SVNUSR} --password=${SVNPWD} --trust-server-cert --non-interactive

# echo Done

cd src

if [[ $answer -eq 5 ]]; then
	echo -n "- Schreibschutz auf src/index.html aufheben, Base-HREF anpassen zu /mobile/... "

	#cp index.html index.html.org

	sed -i.sed -e "s/base href=\".\/\"/base href=\"\/mobile\/\"/g" index.html

	echo "Done"
fi

echo -n "- Aktuelles Datum und Uhrzeit in environment.ts eintragen... "

curr_date="`echo $(date '+%d.%m.%Y')`"
curr_time="`echo $(date '+%H:%M')`"

#cp environments/environment.ts environments/environment.ts.org
#cp environments/environment.prod.ts environments/environment.prod.ts.org

if [[ $answer -eq 4 ]]; then
	env_version="prod"
else
	env_version=v${environment}
fi

sed -i.sed -e "s/#BUILDDATE#/${curr_date}/g;s/#BUILDTIME#/${curr_time} (${env_version})/g" environments/environment.ts
sed -i.sed -e "s/#BUILDDATE#/${curr_date}/g;s/#BUILDTIME#/${curr_time} (${env_version})/g" environments/environment.prod.ts

echo "Done"

if [[ $answer -ne 5 ]]; then
	echo -n "- Ziel-URL $(echo $target | sed -e 's/\\//g') in environment.ts eintragen... "

	sed -i.sed -e "s/baseUrl: '\/mobile'/baseUrl: '${target}'/g" environments/environment.ts
	sed -i.sed -e "s/baseUrl: '\/mobile'/baseUrl: '${target}'/g" environments/environment.prod.ts

	echo Done
else
	sed -i.sed -e "s/baseHref: '.\/'/baseHref: '\/mobile\/'/g" environments/environment.ts
	sed -i.sed -e "s/baseHref: '.\/'/baseHref: '\/mobile\/'/g" environments/environment.prod.ts
fi


echo -n "- Ionic Build aufrufen... "

ionic build --prod --engine=browser

echo "Done"
echo -n "- Geänderte Dateien (index.html, environment.ts) wieder herstellen... "

#if [[ $answer -eq 5 ]]; then
	#cp index.html.org index.html
	#rm -f index.html.org
	# svn revert --username=${SVNUSR} --password=${SVNPWD} --trust-server-cert --non-interactive index.html
	# git checkout index.html
#fi

#cp environments/environment.ts.org environments/environment.ts
#cp environments/environment.prod.ts.org environments/environment.prod.ts
#rm -f environments/environment.ts.org
#rm -f environments/environment.prod.ts.org
# svn revert --username=${SVNUSR} --password=${SVNPWD} --trust-server-cert --non-interactive environments/environment.ts
# svn revert --username=${SVNUSR} --password=${SVNPWD} --trust-server-cert --non-interactive environments/environment.prod.ts
git checkout environments/environment.ts
git checkout environments/environment.prod.ts 

echo "Done"
# echo -n "- Inhalt von www nach ../../../_Webserver/mobile packen... "
cd ..

if [[ ! -d "www" ]]; then
	echo
	echo
	echo "${RED}FEHLER"
	echo
	echo "Der Ordner www ist nicht vorhanden. Bitte Ausgaben des Build-Prozesses prüfen."
	echo "Der Build Prozess ist abgebrochen worden. Alle temporären Änderungen wurden"
	echo "rückgängig gemacht.${ORG}"
	echo

	exit 1
fi

cd www

# rm -f $HOME/SR+mobile-build/mobile.tar*
# tar czf $HOME/SR+mobile-build/mobile.tar.gz *.*
cd ..

# echo "Done"
echo
echo "Der Ionic Build-Vorgang ist abgeschlossen."
echo


# echo -n "${ORG}Soll das erzeugte Archiv im SVN eingecheckt werden? (j/n)${RST}"
# read checkin

# if [[ ${checkin} == "j" || ${checkin} == "J" ]]; then
# 	echo
# 	echo -n "- SVN Commit wird ausgefuehrt... "

# 	cd $HOME/SR+mobile-build
# 	svn commit --username=${SVNUSR} --password=${SVNPWD} --trust-server-cert --non-interactive --message "New build was created on %date% at %time:~0,5%" 

# 	cd $HOME/SR+mobile

# 	echo Done
# else
# 	echo
# 	echo SVN-Checkin wird uebersprungen
# fi

if [[ $answer -eq 6 ]]; then
	echo "- statische HTTP-Responses nach www kopieren"
	cp -r responses/ www/responses/
	cp checkalive.json www/

fi

echo "- Cordova Build aufrufen..."
cordova build ios 
echo 
echo "Der Cordova Build-Vorgang ist abgeschlossen"
echo 

cd ${OLD_PWD}

